#include "PlayerInfo.h"

PlayerInfo::PlayerInfo()
{
	race = Races::None;
	alive = true;
}