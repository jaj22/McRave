#include "ResourceInfo.h"

ResourceInfo::ResourceInfo()
{
	storedUnit;
	gathererCount = 0;
	remainingResources = 0;
	position = Positions::None;
}
ResourceInfo::~ResourceInfo()
{

}
