// Enemy builds based on scouting that need reactions
// Regardless of positioning as well

// Terran
// No gas - expect strictly marines, go fast Reaver
// More than 1 barracks - expect bio, go fast Reaver
// Wall in - expand
// Bunker - expand
// CC - expand

// Protoss
// No gas - expect strictly Zealots, skip goon range
// Higher goon count at transition to midgame - get Reaver first
// Lower goon count - get Observer first